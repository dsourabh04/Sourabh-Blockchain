/** ------------------- ADMIN ---------------------------------- */

export const SAVE_ADMIN_COLLEGES = "SAVE_ADMIN_COLLEGES";
export const SAVE_ADMIN_COMPANIES = "SAVE_ADMIN_COMPANIES";
export const SAVE_ADMIN_COLLEGE = "SAVE_ADMIN_COLLEGE";
export const SAVE_ADMIN_COMPANY = "SAVE_ADMIN_COMPANY";
export const SET_LOGIN_INFO = "SET LOGIN INFO";

/** ------------------- COLLEGE ---------------------------------- */

/** ------------------- COMPANY ---------------------------------- */
export const SAVE_COMPANY_DETAILS = "SAVE_COMPANY_DETAILS";
export const SAVE_COMPANY_CURRENT_EMPLOYEE = "SAVE_COMPANY_CURRENT_EMPLOYEE";
export const SAVE_COMPANY_EMPLOYEE_CERTIFICATE =
  "SAVE_COMPANY_EMPLOYEE_CERTIFICATE";
export const SAVE_COMPANY_CURRENT_APPLICATION =
  "SAVE_COMPANY_CURRENT_APPLICATION";
