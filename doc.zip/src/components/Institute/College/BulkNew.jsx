// import { Bulk } from "./styles";



// export const Bulknewstudent = () => {
    




// }